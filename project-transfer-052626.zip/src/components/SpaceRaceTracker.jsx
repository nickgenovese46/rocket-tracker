import React, { useState, useEffect, useCallback } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { getAgencies, getYearLaunchData } from '../services/api';
import './SpaceRaceTracker.css';

const COLORS = ['#3B82F6', '#10D9A8', '#F59E0B', '#6D5FD8', '#EF4444', '#60A5FA'];

export default function SpaceRaceTracker() {
  const [agencies, setAgencies] = useState([]);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [yearStats, setYearStats] = useState({ total: '—', successRate: '—' });

  const fetchAgencies = useCallback(async (forceFresh = false) => {
    setIsRefreshing(true);
    try {
      // Clear client-side cache when forcing a fresh fetch
      if (forceFresh) {
        try {
          sessionStorage.removeItem('agencies');
        } catch (e) {}
      }

      const data = await getAgencies();

      const chartData = data
        .filter(a => a.launch_library_url)
        .map(a => ({
          name: a.abbrev || a.name,
          launches: a.total_launch_count || 0,
          website: a.website,
        }))
        .sort((a, b) => b.launches - a.launches)
        .slice(0, 6);

      setAgencies(chartData);

      // Use timestamp from API if available
      if (data._timestamp) {
        setLastUpdated(new Date(data._timestamp));
      } else {
        setLastUpdated(new Date());
      }
    } catch (err) {
      console.error('Failed to fetch agencies:', err);
    } finally {
      setIsRefreshing(false);
    }
  }, []);

  const fetchYearStats = useCallback(async (forceFresh = false) => {
  if (forceFresh) {
    try { sessionStorage.removeItem('year_launches'); } catch (e) {}
  }
  try {
    const data = await getYearLaunchData();
    const results = data.results || [];
    const total = data.count ?? results.length;
    const successCount = results.filter(l => {
      const abbrev = l.status?.abbrev?.toLowerCase() || '';
      const name   = l.status?.name?.toLowerCase()   || '';
      return abbrev === 'success' || name.includes('success');
    }).length;
    const rate = results.length > 0
      ? Math.round((successCount / results.length) * 100)
      : 0;
    setYearStats({ total: total.toLocaleString(), successRate: `${rate}%` });
  } catch (err) {
    console.error('Failed to fetch year stats:', err);
  }
}, []);

// Update your initial load useEffect:
useEffect(() => {
  fetchAgencies(true);
  fetchYearStats(true);
}, [fetchAgencies, fetchYearStats]);

// Update your auto-refresh useEffect:
useEffect(() => {
  const interval = setInterval(() => {
    fetchAgencies(false);
    fetchYearStats(false);
  }, 3 * 60 * 1000);
  return () => clearInterval(interval);
}, [fetchAgencies, fetchYearStats]);

  // Initial load - force fresh data on mount
  useEffect(() => {
    fetchAgencies(true);
  }, [fetchAgencies]);

  // Auto-refresh every 3 minutes
  useEffect(() => {
    const interval = setInterval(() => {
      fetchAgencies(false);
    }, 3 * 60 * 1000);

    return () => clearInterval(interval);
  }, [fetchAgencies]);

  const CustomTooltip = ({ active, payload }) => {
    if (!active || !payload?.length) return null;
    const d = payload[0].payload;
    return (
      <div className="chart-tooltip">
        <div className="tt-name">{d.name}</div>
        <div className="tt-val">{d.launches} total launches</div>
        {d.website && (
          <a href={d.website} target="_blank" rel="noreferrer" className="tt-link">
            Visit website ↗
          </a>
        )}
      </div>
    );
  };

  return (
    <div className="space-race">
      {/* STAT CARDS */}
      <div className="stat-cards">
        {[
          { label: 'LAUNCHES IN 2026', value: yearStats.total,       color: 'var(--text-primary)' },
          { label: 'SUCCESS RATE',     value: yearStats.successRate, color: 'var(--teal)'         },
          { label: 'TOTAL PAYLOAD',    value: '312t',                color: 'var(--amber)'        },
          { label: 'OBJECTS IN ORBIT', value: '9,800+',              color: 'var(--purple)'       },
        ].map(s => (
          <div key={s.label} className="stat-card">
            <span className="stat-val" style={{ color: s.color }}>{s.value}</span>
            <span className="stat-label">{s.label}</span>
          </div>
        ))}
      </div>

      {/* Freshness indicator */}
      <div className="freshness-indicator">
        {lastUpdated && (
          <>
            Last updated: {lastUpdated.toLocaleTimeString()}
            {isRefreshing && ' • Refreshing...'}
          </>
        )}
      </div>

      {/* BAR CHART */}
      {agencies.length > 0 && (
        <div className="chart-wrap">
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={agencies} layout="vertical" margin={{ left: 8, right: 24 }}>
              <XAxis type="number" hide />
              <YAxis
                type="category"
                dataKey="name"
                width={52}
                tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
              <Bar dataKey="launches" radius={[0, 4, 4, 0]} barSize={14}>
                {agencies.map((_, i) => (
                  <Cell key={i} fill={COLORS[i % COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Manual Refresh Button */}
      <button 
        onClick={() => { fetchAgencies(true); fetchYearStats(true); }}
        disabled={isRefreshing}
        className="refresh-button"
      >
        ↻ Refresh Launch Data
      </button>
    </div>
  );
}